package datos;

import domain.Producto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author VICTOR
 */
public class ProductoDAO {

    private static final String SQL_SELECT = "SELECT * FROM PRODUCTO";
    private static final String SQL_INSERT = "INSERT INTO PRODUCTO (nombre, precio, puntos) VALUES (?,?,?)";
    private static final String SQL_DELETE = "DELETE FROM PRODUCTO WHERE id_prod = ?";
    private static final String SQL_UPDATE = "UPDATE PRODUCTO SET nombre=?,precio=?,puntos=? WHERE id_prod = ?";
    private Connection conexionTransaccional;

    public ProductoDAO() {
    }

    public ProductoDAO(Connection conexionTransaccional) {
        this.conexionTransaccional = conexionTransaccional;
    }

    public List<Producto> seleccionar() throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Producto producto = null;
        List<Producto> productos = new ArrayList<>();
        try {
            conn = this.conexionTransaccional != null ? this.conexionTransaccional
                    : Conexion.getConnection();
            stmt = conn.prepareStatement(SQL_SELECT);
            rs = stmt.executeQuery();
            while (rs.next()) {
                int id_prod = rs.getInt("id_prod");
                String nombre = rs.getString("nombre");
                int precio = rs.getInt("precio");
                int puntos = rs.getInt("puntos");

                producto = new Producto(id_prod, nombre, precio, puntos);
                productos.add(producto);
            }
        } finally {
            try {

                Conexion.close(rs);
                Conexion.close(stmt);
                if (this.conexionTransaccional == null) {
                    Conexion.close(conn);
                }
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }

        }
        return productos;

    }

    public int insertar(Producto producto) throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;
        int num_reg = 0;
        try {
            conn = this.conexionTransaccional != null ? this.conexionTransaccional
                    : Conexion.getConnection();
            stmt = conn.prepareStatement(SQL_INSERT);
            stmt.setString(1, producto.getNombre());
            stmt.setInt(2, producto.getPuntos());
            stmt.setDouble(3, producto.getPrecio());
            num_reg = stmt.executeUpdate();

        } finally {
            try {
                Conexion.close(stmt);
                if (this.conexionTransaccional == null) {
                    Conexion.close(conn);
                }
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }
        }
        return num_reg;

    }

    public int eliminar(Producto producto) throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;
        int registros = 0;
        try {
            conn = this.conexionTransaccional != null ? this.conexionTransaccional
                    : Conexion.getConnection();
            stmt = conn.prepareStatement(SQL_DELETE);
            stmt.setInt(1, producto.getId_prod());
            registros = stmt.executeUpdate();

        } finally {
            try {
                Conexion.close(stmt);
                if (this.conexionTransaccional == null) {
                    Conexion.close(conn);
                }
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }
        }
        return registros;

    }

    public int actualizar(Producto producto) throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;
        int registros = 0;
        try {
            conn = this.conexionTransaccional != null ? this.conexionTransaccional
                    : Conexion.getConnection();
            stmt = conn.prepareStatement(SQL_UPDATE);
            stmt.setString(1, producto.getNombre());
            stmt.setInt(2, producto.getPuntos());
            stmt.setDouble(3, producto.getPrecio());
            stmt.setInt(4, producto.getId_prod());
            registros = stmt.executeUpdate();

        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
        } finally {
            try {
                Conexion.close(stmt);
                if (this.conexionTransaccional == null) {
                    Conexion.close(conn);
                }
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }
        }
        return registros;

    }

    public static void mostrarDatos() throws SQLException {

        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = Conexion.getConnection();
            stmt = conn.prepareStatement(SQL_SELECT);
            rs = stmt.executeQuery();
            while (rs.next()) {
                int id_prod = rs.getInt("id_prod");
                String nombre = rs.getString("nombre");
                int precio = rs.getInt("precio");
                int puntos = rs.getInt("puntos");

                System.out.println(id_prod + ", " + nombre + ", " + precio + ", " + puntos);
            }
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
            //cerramos los objetos abiertos en orden inverso
        } finally {
            try {

                Conexion.close(rs);
                Conexion.close(stmt);
                Conexion.close(conn);
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }
        }
    }

    public static void mostrarDatosProducto() throws SQLException {
        Scanner sc = new Scanner(System.in);
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        System.out.println("Indica el producto:");
        String nombr = sc.nextLine();
        try {
            conn = Conexion.getConnection();
            stmt = conn.prepareStatement(SQL_SELECT + " where nombre=" + nombr);
            rs = stmt.executeQuery();
            while (rs.next()) {
                int id_prod = rs.getInt("id_prod");
                String nombre = rs.getString("nombre");
                int precio = rs.getInt("precio");
                int puntos = rs.getInt("puntos");

                System.out.println(id_prod + ", " + nombre + ", " + precio + ", " + puntos);
            }
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
            //cerramos los objetos abiertos en orden inverso
        } finally {
            try {

                Conexion.close(rs);
                Conexion.close(stmt);
                Conexion.close(conn);
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }
        }
    }
}
