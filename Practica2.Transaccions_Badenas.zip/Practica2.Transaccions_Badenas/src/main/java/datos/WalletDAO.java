package datos;

import domain.Compra;
import domain.Devolucion;
import domain.Producto;
import domain.Wallet;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author VICTOR
 */
public class WalletDAO {

    private static final String SQL_SELECT = "SELECT * FROM Wallet";
    private static final String SQL_INSERT = "INSERT INTO Wallet (nombre, apellidos, DNI, fechaNacimiento, email, saldo, puntos) VALUES (?,?,?,?,?,default,default)";
    private static final String SQL_DELETE = "DELETE FROM Wallet WHERE DNI = ?";
    private static final String SQL_UPDATE = "UPDATE Wallet SET nombre=?,apellidos=?,DNI=?,fechaNacimiento=?,email=?, puntos=?, saldo=? WHERE id_ewall = ?";
    private Connection conexionTransaccional;

    public WalletDAO() {
    }

    public WalletDAO(Connection conexionTransaccional) {
        this.conexionTransaccional = conexionTransaccional;
    }

    public List<Wallet> seleccionar() throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Wallet wallet = null;
        List<Wallet> wallets = new ArrayList<>();
        try {
            conn = this.conexionTransaccional != null ? this.conexionTransaccional
                    : Conexion.getConnection();
            stmt = conn.prepareStatement(SQL_SELECT);
            rs = stmt.executeQuery();
            while (rs.next()) {
                String nombre = rs.getString("nombre");
                String apellidos = rs.getString("apellidos");
                String DNI = rs.getString("DNI");
                Date fechaNacimiento = rs.getDate("fechaNacimiento");
                String email = rs.getString("email");
                int saldo = rs.getInt("saldo");
                int puntos = rs.getInt("puntos");

                wallet = new Wallet(nombre, apellidos, DNI, fechaNacimiento, email, puntos, saldo);
                wallets.add(wallet);
            }
        } finally {
            try {

                Conexion.close(rs);
                Conexion.close(stmt);
                if (this.conexionTransaccional == null) {
                    Conexion.close(conn);
                }
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }

        }
        return wallets;

    }

    public int insertar(Wallet wallet) throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;
        int num_reg = 0;
        try {
            conn = this.conexionTransaccional != null ? this.conexionTransaccional
                    : Conexion.getConnection();
            stmt = conn.prepareStatement(SQL_INSERT);
            stmt.setString(1, wallet.getNombre());
            stmt.setString(2, wallet.getApellidos());
            stmt.setString(3, wallet.getDNI());
            stmt.setDate(4, wallet.getFechaNacimiento());
            stmt.setString(5, wallet.getEmail());
            num_reg = stmt.executeUpdate();

        } finally {
            try {
                Conexion.close(stmt);
                if (this.conexionTransaccional == null) {
                    Conexion.close(conn);
                }
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }
        }
        return num_reg;

    }

    public int eliminar(Wallet wallet) throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;
        int registros = 0;
        try {
            conn = this.conexionTransaccional != null ? this.conexionTransaccional
                    : Conexion.getConnection();
            stmt = conn.prepareStatement(SQL_DELETE);
            stmt.setString(1, wallet.getDNI());
            registros = stmt.executeUpdate();

        } finally {
            try {
                Conexion.close(stmt);
                if (this.conexionTransaccional == null) {
                    Conexion.close(conn);
                }
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }
        }
        return registros;

    }

    public int actualizar(Wallet wallet) throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;
        int registros = 0;
        try {
            conn = this.conexionTransaccional != null ? this.conexionTransaccional
                    : Conexion.getConnection();
            stmt = conn.prepareStatement(SQL_UPDATE);
            stmt.setString(1, wallet.getNombre());
            stmt.setString(2, wallet.getApellidos());
            stmt.setString(3, wallet.getDNI());
            stmt.setDate(4, wallet.getFechaNacimiento());
            stmt.setString(5, wallet.getEmail());
            stmt.setInt(6, wallet.getPuntos());
            stmt.setDouble(7, wallet.getSaldo());
            stmt.setInt(8, wallet.getId_ewall());
            registros = stmt.executeUpdate();

        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
        } finally {
            try {
                Conexion.close(stmt);
                if (this.conexionTransaccional == null) {
                    Conexion.close(conn);
                }
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }
        }
        return registros;

    }

    public static void mostrarDatosWallet() throws SQLException {
        Scanner sc = new Scanner(System.in);
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        System.out.println("Indica el dni:");
        String dni = sc.nextLine();
        try {
            conn = Conexion.getConnection();
            stmt = conn.prepareStatement(SQL_SELECT + " where DNI=" + dni);
            rs = stmt.executeQuery();
            while (rs.next()) {
                String nombre = rs.getString("nombre");
                String apellidos = rs.getString("apellidos");
                String DNI = rs.getString("DNI");
                Date fechaNacimiento = rs.getDate("fechaNacimiento");
                String email = rs.getString("email");
                double saldo = rs.getInt("saldo");
                int puntos = rs.getInt("puntos");

                System.out.println(nombre + ", " + apellidos + ", " + DNI + ", "
                        + fechaNacimiento + ", " + email + ", " + saldo + ", " + puntos);
            }
            //cerramos los objetos abiertos en orden inverso
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
            //cerramos los objetos abiertos en orden inverso
        } finally {
            try {

                Conexion.close(rs);
                Conexion.close(stmt);
                Conexion.close(conn);
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }
        }
    }

    public static void mostrarDatos() throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = Conexion.getConnection();
            stmt = conn.prepareStatement(SQL_SELECT);
            rs = stmt.executeQuery();
            while (rs.next()) {
                String nombre = rs.getString("nombre");
                String apellidos = rs.getString("apellidos");
                String DNI = rs.getString("DNI");
                Date fechaNacimiento = rs.getDate("fechaNacimiento");
                String email = rs.getString("email");
                double saldo = rs.getInt("saldo");
                int puntos = rs.getInt("puntos");

                System.out.println(nombre + ", " + apellidos + ", " + DNI + ", "
                        + fechaNacimiento + ", " + email + ", " + saldo + ", " + puntos);
            }
            //cerramos los objetos abiertos en orden inverso
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
            //cerramos los objetos abiertos en orden inverso
        } finally {
            try {

                Conexion.close(rs);
                Conexion.close(stmt);
                Conexion.close(conn);
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }
        }
    }

    public int recargarSaldo(Wallet wallet) throws SQLException {
        boolean comprobar = false;
        Connection conn = null;
        PreparedStatement stmt = null;
        Scanner sc = new Scanner(System.in);
        WalletDAO walletDao = new WalletDAO();
        List<Wallet> listaWallets = walletDao.seleccionar();

        Calendar fecha_hoy = Calendar.getInstance();

        int registros = 0;
        try {
            conn = Conexion.getConnection();
            if (fecha_hoy.get(Calendar.DAY_OF_MONTH) <= 5) {
                while (comprobar == false) {

                    System.out.print("Introduzca el DNI: ");
                    String dni_find = sc.nextLine();
                    for (Wallet wallets : listaWallets) {

                        String dni = wallet.getDNI();

                        if (dni.equals(dni_find)) {
                            comprobar = true;
                            int id = wallet.getId_ewall();
                            double saldoAc = wallet.getSaldo();
                        }
                    }
                    if (comprobar == false) {
                        System.out.println("El DNI no existe");
                    }
                }

                System.out.println("Cuanto Saldo quieres ingresar: ");
                int saldo = sc.nextInt();
                sc.nextLine();

                stmt.setDouble(1, wallet.getSaldo() + saldo);
                registros = stmt.executeUpdate();
            } else {
                System.out.println("Solo se puede recargar saldo entre los dias 1 y 5");
            }

        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
        } finally {
            try {
                Conexion.close(stmt);
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }
        }
        return registros;
    }

    public static void pagarProducto() throws SQLException {
        Scanner sc = new Scanner(System.in);
        Connection conexion = null;
        try {
            conexion = Conexion.getConnection();
            if (conexion.getAutoCommit()) {
                conexion.setAutoCommit(false);
            }

            CompraDAO compra = new CompraDAO(conexion);
            ProductoDAO producto = new ProductoDAO(conexion);
            WalletDAO wallet = new WalletDAO(conexion);

            System.out.println("Introduce el Id de la wallet");
            int id_ewall = sc.nextInt();

            Wallet w_aux = null;

            System.out.println("Introduce el Id del producto");
            int id_prod = sc.nextInt();

            Producto p_aux = null;

            int puntos_producto_aux = p_aux.getPuntos();
            double precio_producto_aux = p_aux.getPrecio();

            //LA FECHA ACTUAL 
            java.util.Date utilDate = new java.util.Date();
            java.sql.Date fecha = new java.sql.Date(utilDate.getTime());

            if (w_aux.getSaldo() < precio_producto_aux) {

                System.out.println("No dispone de saldo suficiente ");

            } else {

                w_aux.setSaldo((int) (w_aux.getSaldo() - precio_producto_aux));
                w_aux.setPuntos(w_aux.getPuntos() + puntos_producto_aux);
                wallet.actualizar(w_aux);

                Compra nueva_compra = new Compra(id_ewall, id_prod, fecha);
                compra.insertar(nueva_compra);

                conexion.commit();
                System.out.println("Compra pagada correctamente ");
            }
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
            System.out.println("Error");

            try {
                conexion.rollback();
            } catch (SQLException ex1) {
                ex1.printStackTrace(System.out);
            }
        }
    }

    public static void pagarPuntos() throws SQLException {
        Scanner sc = new Scanner(System.in);
        Connection conexion = null;
        try {
            conexion = Conexion.getConnection();
            if (conexion.getAutoCommit()) {
                conexion.setAutoCommit(false);
            }
            CompraDAO compra = new CompraDAO(conexion);
            ProductoDAO producto = new ProductoDAO(conexion);
            WalletDAO wallet = new WalletDAO(conexion);

            List<Wallet> lista_wallets = wallet.seleccionar();
            System.out.println("Indique el Id de la wallet:");
            int id_ewall = sc.nextInt();
            Wallet wallet_aux = null;

            //IMPRIMIOS LOS PRODUCTOS PARA QUE EL USUARIO SEPA INTERACTUAR
            List<Producto> lista_productos = producto.seleccionar();
            System.out.println("Productos disponibles:");
            for (int i = 0; i < lista_productos.size(); i++) {
                System.out.println(lista_productos.get(i));
                System.out.println("---------------------------------------");
            }

            System.out.println("Indique el Id del producto");
            int id_producto = sc.nextInt();

            //FECHA ACTUAL 
            java.util.Date utilDate = new java.util.Date();
            java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());

            Producto producto_aux = null;
            for (int i = 0; i < lista_productos.size(); i++) {
                Producto get1 = lista_productos.get(i);
                if (get1.getId_prod() == id_producto) {
                    producto_aux = lista_productos.get(i);
                }
            }
            int puntos_producto_aux = producto_aux.getPuntos();
            double precio_producto_aux = producto_aux.getPrecio();

            if (precio_producto_aux >= 5 && wallet_aux.getPuntos() > puntos_producto_aux) {
                wallet_aux.setPuntos(wallet_aux.getPuntos() - puntos_producto_aux);
                wallet.actualizar(wallet_aux);

                Compra nueva_compra = new Compra(id_ewall, id_producto, sqlDate);
                compra.insertar(nueva_compra);

                conexion.commit();
                System.out.println("Pagado correctamente");
            } else {
                if (wallet_aux.getPuntos() < puntos_producto_aux) {
                    System.out.println("Puntos insuficientes");
                } else {
                    System.out.println("El precio del producto ha de ser superior a 5€.");
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
            System.out.println("Error");
            try {
                conexion.rollback();
            } catch (SQLException ex1) {
                ex1.printStackTrace(System.out);
            }
        }
    }

    public static void devolverProducto() throws SQLException {
        Scanner sc = new Scanner(System.in);
        Connection conexion = null;
        try {
            conexion = Conexion.getConnection();
            if (conexion.getAutoCommit()) {
                conexion.setAutoCommit(false);
            }
            CompraDAO compra = new CompraDAO(conexion);
            WalletDAO wallet = new WalletDAO(conexion);
            ProductoDAO producto = new ProductoDAO(conexion);
            DevolucionDAO devolucion = new DevolucionDAO(conexion);

            List<Compra> lista_compras = compra.seleccionar();
            List<Wallet> lista_Wallets = wallet.seleccionar();
            List<Producto> lista_productos = producto.seleccionar();
            List<Devolucion> lista_devoluciones = devolucion.seleccionar();

            for (int i = 0; i < lista_compras.size(); i++) {
                System.out.println("Listado de compras: ");
                System.out.println("[" + i + "] " + lista_compras.get(i));
                System.out.println("************************");
            }

            System.out.println("Indica el numero de compra a devolver");
            int num = sc.nextInt();
            Compra compras = lista_compras.get(num);
            System.out.println(compras);

            Producto productos = null;
            for (int i = 0; i < lista_productos.size(); i++) {
                Producto get1 = lista_productos.get(i);
                if (get1.getId_prod() == compras.getId_prod()) {
                    productos = lista_productos.get(i);
                }
            }
            int puntos_productos = productos.getPuntos();
            double precio_productos = productos.getPrecio();
            System.out.println(productos.toString());

            Wallet wallet_w = null;
            for (int i = 0; i < lista_Wallets.size(); i++) {
                Wallet get = lista_Wallets.get(i);
                if (get.getId_ewall() == compras.getId_ewall()) {
                    wallet_w = lista_Wallets.get(i);
                }
            }

            wallet_w.setSaldo((int) (wallet_w.getSaldo() + productos.getPrecio()));
            wallet_w.setPuntos(wallet_w.getPuntos() - productos.getPuntos());
            wallet.actualizar(wallet_w);
            //FECHA ACTUAL
            java.util.Date utilDate = new java.util.Date();
            java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());

            compra.eliminar(compras);
            Devolucion nueva_devolucion = new Devolucion(wallet_w.getId_ewall(), productos.getId_prod(), sqlDate);
            devolucion.insertar(nueva_devolucion);

            if (wallet_w.getPuntos() + productos.getPuntos() < 5) {
                System.out.println("No se puede devolver el producto");
                try {
                    System.out.println("Error");
                    conexion.rollback();
                } catch (SQLException ex1) {
                    ex1.printStackTrace(System.out);
                }
            } else {
                conexion.commit();
                System.out.println("Devolución realizada");
            }
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
            System.out.println("Error");
            try {
                conexion.rollback();
            } catch (SQLException ex1) {
                ex1.printStackTrace(System.out);
            }
        }
    }
}
