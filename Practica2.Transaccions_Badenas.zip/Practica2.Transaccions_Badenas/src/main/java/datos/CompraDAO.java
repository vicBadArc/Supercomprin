package datos;

import domain.Compra;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author VICTOR
 */
public class CompraDAO {

    private static final String SQL_SELECT = "SELECT * FROM COMPRA";
    private static final String SQL_INSERT = "INSERT INTO COMPRA (id_com, id_ewall, id_prod, fecha) VALUES (?,?,?,?)";
    private static final String SQL_DELETE = "DELETE FROM COMPRA WHERE id_com = ?";
    private static final String SQL_UPDATE = "UPDATE COMPRA SET id_prod=?,id_ewall=?,fecha=? WHERE id_com = ?";
    private Connection conexionTransaccional;

    public CompraDAO() {
    }

    public CompraDAO(Connection conexionTransaccional) {
        this.conexionTransaccional = conexionTransaccional;
    }

    public List<Compra> seleccionar() throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Compra compra = null;
        List<Compra> compras = new ArrayList<>();
        try {
            conn = this.conexionTransaccional != null ? this.conexionTransaccional
                    : Conexion.getConnection();
            stmt = conn.prepareStatement(SQL_SELECT);
            rs = stmt.executeQuery();
            while (rs.next()) {
                int id_com = rs.getInt("id_com");
                int id_ewall = rs.getInt("id_ewall");
                int id_prod = rs.getInt("id_prod");
                Date fecha = rs.getDate("fecha");

                compra = new Compra(id_com, id_ewall, id_prod, fecha);
                compras.add(compra);
            }
        } finally {
            try {

                Conexion.close(rs);
                Conexion.close(stmt);
                if (this.conexionTransaccional == null) {
                    Conexion.close(conn);
                }
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }

        }
        return compras;

    }

    public int insertar(Compra compra) throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;
        int num_reg = 0;
        try {
            conn = this.conexionTransaccional != null ? this.conexionTransaccional
                    : Conexion.getConnection();
            stmt = conn.prepareStatement(SQL_INSERT);
            stmt.setInt(1, compra.getId_prod());
            stmt.setInt(2, compra.getId_ewall());
            stmt.setDate(3, compra.getFecha());
            num_reg = stmt.executeUpdate();

        } finally {
            try {
                Conexion.close(stmt);
                if (this.conexionTransaccional == null) {
                    Conexion.close(conn);
                }
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }
        }
        return num_reg;

    }

    public int eliminar(Compra compra) throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;
        int registros = 0;
        try {
            conn = this.conexionTransaccional != null ? this.conexionTransaccional
                    : Conexion.getConnection();
            stmt = conn.prepareStatement(SQL_DELETE);
            stmt.setInt(1, compra.getId_com());
            registros = stmt.executeUpdate();

        } finally {
            try {
                Conexion.close(stmt);
                if (this.conexionTransaccional == null) {
                    Conexion.close(conn);
                }
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }
        }
        return registros;

    }

    public int actualizar(Compra compra) throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;
        int registros = 0;
        try {
            conn = this.conexionTransaccional != null ? this.conexionTransaccional
                    : Conexion.getConnection();
            stmt = conn.prepareStatement(SQL_UPDATE);
            stmt.setInt(1, compra.getId_prod());
            stmt.setInt(2, compra.getId_ewall());
            stmt.setDate(3, compra.getFecha());
            stmt.setInt(4, compra.getId_com());
            registros = stmt.executeUpdate();

        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
        } finally {
            try {
                Conexion.close(stmt);
                if (this.conexionTransaccional == null) {
                    Conexion.close(conn);
                }
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }
        }
        return registros;

    }

    public static void mostrarDatos() throws SQLException {

        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = Conexion.getConnection();
            stmt = conn.prepareStatement(SQL_SELECT);
            rs = stmt.executeQuery();
            while (rs.next()) {
                int id_com = rs.getInt("id_com");
                int id_ewall = rs.getInt("id_ewall");
                int id_prod = rs.getInt("id_prod");
                Date fecha = rs.getDate("fecha");

                System.out.println(id_com + ", " + id_ewall + ", " + id_prod + ", " + fecha);
            }
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
            //cerramos los objetos abiertos en orden inverso
        } finally {
            try {

                Conexion.close(rs);
                Conexion.close(stmt);
                Conexion.close(conn);
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }
        }
    }
     
    public static void mostrarDatosCompra() throws SQLException {
        Scanner sc = new Scanner(System.in);
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        System.out.println("Indica el id de la compra: ");
        int id = sc.nextInt();
        try {
            conn = Conexion.getConnection();
            stmt = conn.prepareStatement(SQL_SELECT + " where id_com=" + id);
            rs = stmt.executeQuery();
            while (rs.next()) {
                int id_com = rs.getInt("id_com");
                int id_ewall = rs.getInt("id_ewall");
                int id_prod = rs.getInt("id_prod");
                Date fecha = rs.getDate("fecha");

                System.out.println(id_com + ", " + id_ewall + ", " + id_prod + ", " + fecha);
            }
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
            //cerramos los objetos abiertos en orden inverso
        } finally {
            try {

                Conexion.close(rs);
                Conexion.close(stmt);
                Conexion.close(conn);
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }
        }
    }
}
