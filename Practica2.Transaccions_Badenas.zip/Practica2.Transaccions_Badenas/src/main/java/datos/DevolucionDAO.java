package datos;

import domain.Devolucion;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author VICTOR
 */
public class DevolucionDAO {
    private static final String SQL_SELECT = "SELECT * FROM DEVOLUCION";
    private static final String SQL_INSERT = "INSERT INTO DEVOLUCION (id_dev, id_com, id_prod, fecha) VALUES (?,?,?,?)";
    private static final String SQL_DELETE = "DELETE FROM DEVOLUCION WHERE id_dev = ?";
    private static final String SQL_UPDATE = "UPDATE DEVOLUCION SET id_com=?,id_prod=?, fecha=? WHERE id_dev = ?";
    private Connection conexionTransaccional;


    public DevolucionDAO() {
    }

    public DevolucionDAO(Connection conexionTransaccional) {
        this.conexionTransaccional = conexionTransaccional;
    }

    public List<Devolucion> seleccionar() throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Devolucion devolucion = null;
        List<Devolucion> devoluciones = new ArrayList<>();
        try {
            conn = this.conexionTransaccional != null ? this.conexionTransaccional
                    : Conexion.getConnection();
            stmt = conn.prepareStatement(SQL_SELECT);
            rs = stmt.executeQuery();
            while (rs.next()) {
                int id_dev = rs.getInt("id_dev");
                int id_com = rs.getInt("id_com");
                int id_prod = rs.getInt("id_prod");
                Date fecha = rs.getDate("fecha");
                
                devolucion = new Devolucion(id_dev, id_com, id_prod, fecha);
                devoluciones.add(devolucion);
            }
        } finally {
            try {

                Conexion.close(rs);
                Conexion.close(stmt);
                if (this.conexionTransaccional == null) {
                    Conexion.close(conn);
                }
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }

        }
        return devoluciones;

    }

    public int insertar(Devolucion devolucion) throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;
        int num_reg = 0;
        try {
            conn = this.conexionTransaccional != null ? this.conexionTransaccional
                    : Conexion.getConnection();
            stmt = conn.prepareStatement(SQL_INSERT);
            stmt.setInt(1, devolucion.getId_com());
            stmt.setInt(2, devolucion.getId_prod());
            stmt.setDate(3, devolucion.getFecha());
            num_reg = stmt.executeUpdate();

        } finally {
            try {
                Conexion.close(stmt);
                if (this.conexionTransaccional == null) {
                    Conexion.close(conn);
                }
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }
        }
        return num_reg;

    }
    
    public int eliminar(Devolucion compra) throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;
        int registros = 0;
        try {
            conn = this.conexionTransaccional != null ? this.conexionTransaccional
                    : Conexion.getConnection();
            stmt = conn.prepareStatement(SQL_DELETE);
            stmt.setInt(1, compra.getId_dev());
            registros = stmt.executeUpdate();

        } finally {
            try {
                Conexion.close(stmt);
                if (this.conexionTransaccional == null) {
                    Conexion.close(conn);
                }
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }
        }
        return registros;

    }
    
    public int actualizar(Devolucion devolucion) throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;
        int registros = 0;
        try {
            conn = this.conexionTransaccional != null ? this.conexionTransaccional
                    : Conexion.getConnection();
            stmt = conn.prepareStatement(SQL_UPDATE);
            stmt.setInt(1, devolucion.getId_dev());
            stmt.setInt(2, devolucion.getId_prod());
            stmt.setDate(3, devolucion.getFecha());
            stmt.setInt(4, devolucion.getId_com());
            registros = stmt.executeUpdate();

        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
        } finally {
            try {
                Conexion.close(stmt);
                if (this.conexionTransaccional == null) {
                    Conexion.close(conn);
                }
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }
        }
        return registros;

    }
    
     public static void mostrarDatos() throws SQLException {
      
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = Conexion.getConnection();
            stmt = conn.prepareStatement(SQL_SELECT );
            rs = stmt.executeQuery();
            while (rs.next()) {
                int id_dev = rs.getInt("id_dev");
                int id_com = rs.getInt("id_com");
                int id_prod = rs.getInt("id_prod");
                Date fecha = rs.getDate("fecha");

                System.out.println(id_dev + ", " + id_com + ", " + id_prod + ", " + fecha);
            }
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
            //cerramos los objetos abiertos en orden inverso
        } finally {
            try {

                Conexion.close(rs);
                Conexion.close(stmt);
                Conexion.close(conn);
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }
        }
    }
    
     public static void mostrarDatosDevolucion() throws SQLException {
        Scanner sc = new Scanner(System.in);
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        System.out.println("Indica el id de la devolución: ");
        int id = sc.nextInt();
        try {
            conn = Conexion.getConnection();
            stmt = conn.prepareStatement(SQL_SELECT + " where id_dev=" + id);
            rs = stmt.executeQuery();
            while (rs.next()) {
                int id_dev = rs.getInt("id_dev");
                int id_com = rs.getInt("id_com");
                int id_prod = rs.getInt("id_prod");
                Date fecha = rs.getDate("fecha");

                System.out.println(id_dev + ", " + id_com + ", " + id_prod + ", " + fecha);
            }
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
            //cerramos los objetos abiertos en orden inverso
        } finally {
            try {

                Conexion.close(rs);
                Conexion.close(stmt);
                Conexion.close(conn);
            } catch (SQLException ex) {
                ex.printStackTrace(System.out);
            }
        }
    }
}
