package domain;

import java.sql.Date;

/**
 *
 * @author VICTOR
 */
public class Devolucion {

    private int id_dev;
    private int id_com;
    private int id_prod;
    private Date fecha;

    public Devolucion() {
    }

    public Devolucion(int id_dev) {
        this.id_dev = id_dev;
    }

    public Devolucion(int id_com, int id_prod, Date fecha) {
        this.id_com = id_com;
        this.fecha = fecha;
    }

    public Devolucion(int id_dev, int id_com, int id_prod, Date fecha) {
        this.id_dev = id_dev;
        this.id_com = id_com;
        this.fecha = fecha;
    }

    public int getId_dev() {
        return id_dev;
    }

    public void setId_dev(int id_dev) {
        this.id_dev = id_dev;
    }

    public int getId_com() {
        return id_com;
    }

    public void setId_com(int id_com) {
        this.id_com = id_com;
    }

    public int getId_prod() {
        return id_prod;
    }

    public void setId_prod(int id_prod) {
        this.id_prod = id_prod;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    @Override
    public String toString() {
        return "Devolucion{" + "id_dev=" + id_dev + ", compra=" + id_com + ", fecha=" + fecha + '}';
    }

}
