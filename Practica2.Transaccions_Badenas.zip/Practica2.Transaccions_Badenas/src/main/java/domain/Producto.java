/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domain;

/**
 *
 * @author VICTOR
 */
public class Producto {

    private int id_prod;
    private String nombre;
    private double precio;
    private int puntos;

    public Producto() {
    }

    public Producto(int id_prod) {
        this.id_prod = id_prod;
    }

    public Producto(String nombre, double precio, int puntos) {
        this.nombre = nombre;
        this.precio = precio;
        this.puntos = puntos;
    }

    public Producto(int id_prod, String nombre, double precio, int puntos) {
        this.id_prod = id_prod;
        this.nombre = nombre;
        this.precio = precio;
        this.puntos = puntos;
    }

    public int getId_prod() {
        return id_prod;
    }

    public void setId_prod(int id_prod) {
        this.id_prod = id_prod;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getPuntos() {
        return puntos;
    }

    public void setPuntos(int puntos) {
        this.puntos = puntos;
    }

    @Override
    public String toString() {
        return "Producto{" + "id_prod=" + id_prod + ", nombre=" + nombre + ", precio=" + precio + ", puntos=" + puntos + '}';
    }

}
