package domain;

import java.sql.Date;

/**
 *
 * @author VICTOR
 */
public class Compra {

    private int id_com;
    private int id_ewall;
    private int id_prod;
    private Date fecha;

    public Compra() {
    }

    public Compra(int id_com) {
        this.id_com = id_com;
    }

    public Compra(int id_ewall, int id_prod, Date fecha) {
        this.id_ewall = id_ewall;
        this.id_prod = id_prod;
        this.fecha = fecha;
    }

    public Compra(int id_com, int id_ewall, int id_prod, Date fecha) {
        this.id_com = id_com;
        this.id_ewall = id_ewall;
        this.id_prod = id_prod;
        this.fecha = fecha;
    }

    public int getId_com() {
        return id_com;
    }

    public void setId_com(int id_com) {
        this.id_com = id_com;
    }

    public int getId_ewall() {
        return id_ewall;
    }

    public void setId_ewall(int id_ewall) {
        this.id_ewall = id_ewall;
    }

    public int getId_prod() {
        return id_prod;
    }

    public void setId_prod(int id_prod) {
        this.id_prod = id_prod;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    @Override
    public String toString() {
        return "Compra{" + "id_com=" + id_com + ", id_ewall=" + id_ewall + ", id_prod=" + id_prod + ", fecha=" + fecha + '}';
    }

}
