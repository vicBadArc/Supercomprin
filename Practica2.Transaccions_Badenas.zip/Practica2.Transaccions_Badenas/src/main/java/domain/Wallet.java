package domain;

import java.sql.Date;

/**
 *
 * @author VICTOR
 */
public class Wallet {

    //Declaramos los atributos necesarios
    private int id_ewall;
    private String nombre;
    private String apellidos;
    private String DNI;
    private Date fechaNacimiento;
    private String email;
    private double saldo;
    private int puntos;

    //Ahora crearemos los constructores 
    public Wallet() {
    }

    public Wallet(String DNI) {
        this.DNI = DNI;
    }
    
    public Wallet(String nombre, String apellidos, String DNI, Date fechaNacimiento, String email) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.DNI = DNI;
        this.fechaNacimiento = fechaNacimiento;
        this.email = email;
    }

    public Wallet(String nombre, String apellidos, String DNI, Date fechaNacimiento, String email, double saldo, int puntos) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.DNI = DNI;
        this.fechaNacimiento = fechaNacimiento;
        this.email = email;
        this.saldo = saldo;
        this.puntos = puntos;
    }
    
    //Constructor con todos los atributos

    public Wallet(int id_ewall, String nombre, String apellidos, String DNI, Date fechaNacimiento, String email, double saldo, int puntos) {
        this.id_ewall = id_ewall;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.DNI = DNI;
        this.fechaNacimiento = fechaNacimiento;
        this.email = email;
        this.saldo = saldo;
        this.puntos = puntos;
    }
    
    //Ahora añadimos los métodos get() y set() para cada uno de los atributos.
    public int getId_ewall() {
        return id_ewall;
    }

    public void setId_ewall(int id_ewall) {
        this.id_ewall = id_ewall;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getDNI() {
        return DNI;
    }

    public void setDNI(String DNI) {
        this.DNI = DNI;
    }

    public Date getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(Date fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public int getPuntos() {
        return puntos;
    }

    public void setPuntos(int puntos) {
        this.puntos = puntos;
    }

    //añadimos el método ToString(), para imprimir el estado del objeto en cualquier momento.
    @Override
    public String toString() {
        return "Wallet{" + "id_ewall=" + id_ewall + ", nombre=" + nombre + ", apellidos=" + apellidos + ", DNI=" + DNI + ", fechaNacimiento=" + fechaNacimiento + ", email=" + email + ", saldo=" + saldo + ", puntos=" + puntos + '}';
    }

}
