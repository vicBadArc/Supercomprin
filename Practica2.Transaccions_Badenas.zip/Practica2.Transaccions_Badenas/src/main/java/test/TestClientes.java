package test;

import datos.CompraDAO;
import datos.Conexion;
import datos.DevolucionDAO;
import datos.ProductoDAO;
import datos.WalletDAO;
import domain.Compra;
import domain.Devolucion;
import domain.Producto;
import domain.Wallet;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author VICTOR
 */
public class TestClientes {

    public static void main(String[] args) throws SQLException {
        Scanner sn = new Scanner(System.in);
        boolean salir = false;
        Connection conexion = null;
        try {
            conexion = Conexion.getConnection();
            if (conexion.getAutoCommit()) {
                conexion.setAutoCommit(false);
            }

            WalletDAO walletDao = new WalletDAO(conexion);
            List<Wallet> wallets = walletDao.seleccionar();
            ProductoDAO productoDao = new ProductoDAO(conexion);
            List<Producto> productos = productoDao.seleccionar();
            CompraDAO compraDao = new CompraDAO(conexion);
            List<Compra> compras = compraDao.seleccionar();
            DevolucionDAO devolucionDao = new DevolucionDAO(conexion);
            List<Devolucion> devoluciones = devolucionDao.seleccionar();

            int opcion; //Guardaremos la opcion del usuario
            do {
                System.out.println("");
                System.out.println("Menu club Supercomprín:");
                System.out.println(" -------------------------");
                System.out.println(" 01. Mostrar wallets");
                System.out.println(" 02. Buscar wallet");
                System.out.println(" 03. Crear Wallet");
                System.out.println(" 04. Eliminar Wallet");
                System.out.println(" 05. Actualizar wallet");

                System.out.println(" 06. Mostrar productos");
                System.out.println(" 07. Buscar producto");
                System.out.println(" 08. Crear producto");
                System.out.println(" 09. Eliminar producto");
                System.out.println(" 10. Actualizar producto");

                System.out.println(" 11. Mostrar compras");
                System.out.println(" 12. Buscar compra");
                System.out.println(" 13. Crear compra");
                System.out.println(" 14. Eliminar compra");
                System.out.println(" 15. Actualizar compra");

                System.out.println(" 16. Mostrar devoluciones");
                System.out.println(" 17. Buscar devolucion");
                System.out.println(" 18. Crear devolucion");
                System.out.println(" 19. Eliminar devolucion");
                System.out.println(" 20. Actualizar devolucion");
                System.out.println(" -------------------------");
                System.out.println(" 21. Pagar");
                System.out.println(" 22. Pagar con puntos");
                System.out.println(" 23. Recargar");
                System.out.println(" 24. Devolver producto");
                System.out.println(" 0. Salir");
                try {
                    System.out.println("Escribe una de las opciones");
                    System.out.print("-->");
                    opcion = sn.nextInt();
                    switch (opcion) {
                        case 1 -> {
                            System.out.println("Has seleccionado mostrar wallets");
                            WalletDAO.mostrarDatos();
                        }
                        case 2 -> {
                            System.out.println("Has seleccionado buscar wallet");
                            WalletDAO.mostrarDatosWallet();
                        }
                        case 3 -> {
                            System.out.println("Has seleccionado crear wallet");
                            DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                            LocalDate fechaNac = LocalDate.parse("15/08/1993", fmt);
                            LocalDate ahora = LocalDate.now();
                            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                            Date Fecha = (Date) sdf.parse("15/08/1993");

                            Period periodo = Period.between(fechaNac, ahora);
                            if (periodo.getYears() > 17) {
                                Wallet walletIn = new Wallet("marc", "gomez perez", "26958652K", Fecha, "marc@corre.es", 3600, 6522);
                                walletDao.insertar(walletIn);
                                wallets.forEach(wallet -> {
                                    System.out.println("Wallet = " + wallet);
                                });
                            } else {
                                System.out.println("Los menores de eda no se pueden registar");
                            }
                        }
                        case 4 -> {
                            System.out.println("Has seleccionado elimnar wallet");

                            Wallet walletAc = new Wallet("565665J");
                            walletDao.eliminar(walletAc);
                            wallets.forEach(wallet -> {
                                System.out.println("");
                            });
                        }
                        case 5 -> {
                            System.out.println("Has seleccionado actualizar wallet");
                            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                            Date Fecha = (Date) sdf.parse("11/09/1986");

                            System.out.println("Has seleccionado actualizar wallets");
                            Wallet walletAc = new Wallet("Fran", "martin martinez", "65962658P", Fecha, "Fran@correo.es", 5600, 10);
                            walletDao.actualizar(walletAc);
                            wallets.forEach(wallet -> {
                                System.out.println("Wallet = " + wallet);
                            });
                        }
                        case 6 -> {
                            System.out.println("Has seleccionado mostrar productos");
                            ProductoDAO.mostrarDatos();
                        }
                        case 7 -> {
                            System.out.println("Has seleccionado buscar producto");
                            ProductoDAO.mostrarDatosProducto();
                        }
                        case 8 -> {
                            System.out.println("Has seleccionado crear producto");
                            Producto productoIn = new Producto("pepsi", 5, 10);
                            productoDao.insertar(productoIn);
                            productos.forEach(producto -> {
                                System.out.println("");
                            });
                        }
                        case 9 -> {
                            System.out.println("Has seleccionado elimnar producto");
                            Producto productoIn = new Producto(10);
                            productoDao.eliminar(productoIn);
                            productos.forEach(producto -> {
                                System.out.println("");
                            });
                        }
                        case 10 -> {
                            System.out.println("Has seleccionado actualizar producto");
                            Producto productoIn = new Producto("pepsi", 5, 10);
                            productoDao.actualizar(productoIn);
                            productos.forEach(producto -> {
                                System.out.println("");
                            });
                        }

                        case 11 -> {
                            System.out.println("Has seleccionado mostrar compras");
                            CompraDAO.mostrarDatos();

                        }
                        case 12 -> {
                            System.out.println("Has seleccionado buscar compra");
                            CompraDAO.mostrarDatosCompra();
                        }
                        case 13 -> {
                            System.out.println("Has seleccionado crear compras");

                            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                            Date Fecha = (Date) sdf.parse("09/11/2021");

                            Compra compraIn = new Compra(5, 5, 10, Fecha);
                            compraDao.insertar(compraIn);
                            compras.forEach(compra -> {
                                System.out.println("");
                            });
                        }
                        case 14 -> {
                            System.out.println("Has seleccionado elimnar compra");
                            Compra compraAc = new Compra(23);
                            compraDao.eliminar(compraAc);
                            compras.forEach(compra -> {
                                System.out.println("");
                            });
                        }
                        case 15 -> {
                            System.out.println("Has seleccionado actualizar compra");

                            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                            Date Fecha = (Date) sdf.parse("09/11/2021");

                            Compra compraIn = new Compra(4, 65, 25, Fecha);
                            compraDao.actualizar(compraIn);
                            compras.forEach(wallet -> {
                                System.out.println("");
                            });
                        }
                        case 16 -> {
                            System.out.println("Has seleccionado mostrar devoluciones");
                            DevolucionDAO.mostrarDatos();
                        }
                        case 17 -> {
                            System.out.println("Has seleccionado buscar devolucion");
                            DevolucionDAO.mostrarDatosDevolucion();
                        }
                        case 18 -> {
                            System.out.println("Has seleccionado crear devoluciones");
                            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                            Date Fecha = (Date) sdf.parse("09/11/2021");

                            Devolucion devolucionIn = new Devolucion(5, 5, 10, Fecha);
                            devolucionDao.insertar(devolucionIn);
                            devoluciones.forEach(devolucion -> {
                                System.out.println("");
                            });
                        }
                        case 19 -> {
                            System.out.println("Has seleccionado elimnar devoluciones");
                            Devolucion devolucionAc = new Devolucion(56);
                            devolucionDao.eliminar(devolucionAc);
                            devoluciones.forEach(devolucion -> {
                                System.out.println("");
                            });
                        }
                        case 20 -> {
                            System.out.println("Has seleccionado actualizar devoluciones");
                            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                            Date Fecha = (Date) sdf.parse("09/11/2021");

                            Devolucion devolucionIn = new Devolucion(5, 5, 10, Fecha);
                            devolucionDao.actualizar(devolucionIn);
                            devoluciones.forEach(devolucion -> {
                                System.out.println("");
                            });
                        }
                        case 21 -> {
                            System.out.println("Has seleccionado pagar");
                            WalletDAO.pagarProducto();
                        }
                        case 22 -> {
                            System.out.println("Has seleccionado pagar con puntos");
                            WalletDAO.pagarPuntos();
                        }
                        case 23 -> {
                            System.out.println("Has seleccionado recargar");
                      
                            Wallet productoIn = new Wallet();
                            walletDao.recargarSaldo(productoIn);
                            wallets.forEach(producto -> {
                                System.out.println("");
                            });
                        }
                        case 24 -> {
                            System.out.println("Has seleccionado devolver producto");
                            WalletDAO.devolverProducto();
                        }

                        case 0 -> {
                            System.out.println("Adios, gracias por utilizar nuestro servicio!!");
                            salir = true;
                        }

                        default -> {
                            System.out.println("Has selecionado " + opcion + " elige una opcion entre 0 y 24");
                            System.out.println("");
                        }
                    }
                } catch (InputMismatchException e) {
                    System.out.println("Debes insertar un número");
                    sn.next();
                } catch (ParseException ex) {
                    Logger.getLogger(TestClientes.class.getName()).log(Level.SEVERE, null, ex);
                }
            } while (!salir);

            conexion.commit();
            System.out.println("Se ha hecho commit de la transaccion");
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
            System.out.println("Entramos al rollback");
            try {
                conexion.rollback();
            } catch (SQLException ex1) {
                ex1.printStackTrace(System.out);
            }
        }
    }
}
